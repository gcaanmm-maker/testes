import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Alert, SafeAreaView, ScrollView, StatusBar, Text, TextInput, TouchableOpacity, Vibration, View } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { WebView } from 'react-native-webview';
import { Audio } from 'expo-av';
import AsyncStorage from '@react-native-async-storage/async-storage';
import styles from './styles';
import { supabase } from './supabase';

export default function JoguinhoScreen() {
  const [modo, setModo] = useState(null);
  const [diff, setDiff] = useState('medio');
  const [muted, setMuted] = useState(false);
  const [volume, setVolume] = useState(1);
  const [ranking, setRanking] = useState({ jogos: 0, playerWins: 0, aiWins: 0, verdeWins: 0, vermelhoWins: 0, onlineWins: 0, onlineLosses: 0 });
  const [codigoSala, setCodigoSala] = useState('');
  const [codigoInput, setCodigoInput] = useState('');
  const [onlineStatus, setOnlineStatus] = useState('Pronto para jogar online');

  const webviewRef = useRef(null);
  const intervalRef = useRef(null);
  const soundRefs = useRef({});
  const mutedRef = useRef(false);
  const volumeRef = useRef(1);
  const baseVolumeRef = useRef({ chute: 0.45, gol: 0.85, trave: 0.55, torcida: 0.22, apito: 0.75 });

  async function stopAllNativeSounds() {
    try {
      for (const sound of Object.values(soundRefs.current)) {
        try {
          const status = await sound.getStatusAsync();
          if (status.isLoaded) {
            await sound.stopAsync();
            await sound.setPositionAsync(0);
          }
        } catch (error) {
          console.log('Erro parando som:', error);
        }
      }
    } catch (error) {
      console.log('Erro stopAllNativeSounds:', error);
    }
  }

  useFocusEffect(useCallback(() => {
    return () => {
      stopAllNativeSounds();
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, []));

  useEffect(() => {
    AsyncStorage.getItem('@copa_hub_ranking')
      .then((value) => { if (value) setRanking((old) => ({ ...old, ...JSON.parse(value) })); })
      .catch((error) => console.log('Erro ranking:', error));
  }, []);

  async function saveRanking(next) {
    setRanking(next);
    try {
      await AsyncStorage.setItem('@copa_hub_ranking', JSON.stringify(next));
    } catch (error) {
      console.log('Erro salvando ranking:', error);
    }
  }

  async function resetRanking() {
    await saveRanking({ jogos: 0, playerWins: 0, aiWins: 0, verdeWins: 0, vermelhoWins: 0, onlineWins: 0, onlineLosses: 0 });
  }

  function registerGameResult(result) {
    const next = { ...ranking, jogos: (ranking.jogos || 0) + 1 };
    if (result.mode === 'ai') {
      if (result.winner === 'p1') next.playerWins = (next.playerWins || 0) + 1;
      if (result.winner === 'p2') next.aiWins = (next.aiWins || 0) + 1;
    } else if (result.mode === 'host' || result.mode === 'guest') {
      const me = result.mode === 'host' ? 'p1' : 'p2';
      if (result.winner === me) next.onlineWins = (next.onlineWins || 0) + 1;
      else next.onlineLosses = (next.onlineLosses || 0) + 1;
    } else {
      if (result.winner === 'p1') next.verdeWins = (next.verdeWins || 0) + 1;
      if (result.winner === 'p2') next.vermelhoWins = (next.vermelhoWins || 0) + 1;
    }
    saveRanking(next);
  }

  useEffect(() => {
    let mounted = true;
    async function loadNativeSounds() {
      try {
        await Audio.setAudioModeAsync({
          playsInSilentModeIOS: true,
          allowsRecordingIOS: false,
          staysActiveInBackground: false,
          shouldDuckAndroid: true,
          playThroughEarpieceAndroid: false,
        });

        const soundFiles = {
          chute: require('./assets/sounds/chute.mp3'),
          gol: require('./assets/sounds/gol.mp3'),
          trave: require('./assets/sounds/trave.mp3'),
          torcida: require('./assets/sounds/torcida.mp3'),
          apito: require('./assets/sounds/apito.mp3'),
        };

        const loaded = {};
        for (const key of Object.keys(soundFiles)) {
          const { sound } = await Audio.Sound.createAsync(soundFiles[key], {
            shouldPlay: false,
            volume: baseVolumeRef.current[key] * volumeRef.current,
            isLooping: key === 'torcida',
          });
          loaded[key] = sound;
        }
        if (mounted) soundRefs.current = loaded;
      } catch (error) {
        console.log('Erro ao carregar sons:', error);
      }
    }

    loadNativeSounds();
    return () => {
      mounted = false;
      stopAllNativeSounds();
      Object.values(soundRefs.current).forEach((sound) => {
        try { sound.unloadAsync(); }
        catch (error) { console.log('Erro unload som:', error); }
      });
    };
  }, []);

  useEffect(() => {
    mutedRef.current = muted;
    volumeRef.current = volume;
    Object.entries(soundRefs.current).forEach(async ([name, sound]) => {
      try { await sound.setVolumeAsync(muted ? 0 : baseVolumeRef.current[name] * volume); }
      catch (error) { console.log('Erro volume:', error); }
    });
  }, [muted, volume]);

  async function playNativeSound(name) {
    try {
      const sound = soundRefs.current[name];
      if (!sound) return;
      await sound.setVolumeAsync(mutedRef.current ? 0 : baseVolumeRef.current[name] * volumeRef.current);
      if (name === 'torcida') {
        const status = await sound.getStatusAsync();
        if (status.isLoaded && !status.isPlaying) await sound.playAsync();
        return;
      }
      await sound.setPositionAsync(0);
      await sound.playAsync();
    } catch (error) {
      console.log('Erro som:', name, error);
    }
  }

  const gerarCodigo = () => Math.random().toString(36).slice(2, 6).toUpperCase();

  async function criarSalaOnline() {
    const codigo = gerarCodigo();
    const estadoInicial = { ball: { x: 0.5, y: 0.5, vx: 0, vy: 0 }, p1: { x: 0.5, y: 0.82 }, p2: { x: 0.5, y: 0.18 }, sc1: 0, sc2: 0, running: false, paused: false, gameOver: false, winner: null };
    const { error } = await supabase.from('jogo_online_salas').insert({ codigo, estado: estadoInicial, atualizado_em: new Date().toISOString() });
    if (error) { setOnlineStatus(error.message); Alert.alert('Erro ao criar sala', error.message); return; }
    setCodigoSala(codigo);
    setCodigoInput(codigo);
    setModo('host');
    setOnlineStatus('Sala criada: ' + codigo);
  }

  async function entrarSalaOnline() {
    const codigo = codigoInput.trim().toUpperCase();
    if (!codigo) return Alert.alert('Atenção', 'Digite o código da sala');
    const { data, error } = await supabase.from('jogo_online_salas').select('*').eq('codigo', codigo).maybeSingle();
    if (error || !data) {
      setOnlineStatus(error?.message || 'Sala não encontrada');
      Alert.alert('Erro', error?.message || 'Sala não encontrada');
      return;
    }
    setCodigoSala(codigo);
    setModo('guest');
    setOnlineStatus('Entrou na sala: ' + codigo);
  }

  useEffect(() => {
    if (intervalRef.current) clearInterval(intervalRef.current);
    if (modo !== 'host' && modo !== 'guest') return;
    if (!codigoSala) return;
    intervalRef.current = setInterval(async () => {
      const { data } = await supabase.from('jogo_online_salas').select('estado').eq('codigo', codigoSala).maybeSingle();
      if (data?.estado) {
        webviewRef.current?.injectJavaScript(`window.receiveOnlineState && window.receiveOnlineState(${JSON.stringify(data.estado)}); true;`);
      }
    }, 250);
    return () => { if (intervalRef.current) clearInterval(intervalRef.current); };
  }, [modo, codigoSala]);

  async function handleWebViewMessage(event) {
    try {
      const data = JSON.parse(event.nativeEvent.data);
      if (data?.type === 'sound') playNativeSound(data.name);
      if (data?.type === 'vibrate') Vibration.vibrate(data.duration || 40);
      if (data?.type === 'gameOver') registerGameResult(data);
      if (data?.type === 'estado' && codigoSala && (modo === 'host' || modo === 'guest')) {
        if (modo === 'guest') {
          const { data: row } = await supabase.from('jogo_online_salas').select('estado').eq('codigo', codigoSala).maybeSingle();
          const atual = row?.estado || {};
          await supabase.from('jogo_online_salas').update({ estado: { ...atual, p2: data.estado.p2 || atual.p2 }, atualizado_em: new Date().toISOString() }).eq('codigo', codigoSala);
        } else {
          await supabase.from('jogo_online_salas').update({ estado: data.estado, atualizado_em: new Date().toISOString() }).eq('codigo', codigoSala);
        }
      }
    } catch (error) {
      console.log('Mensagem WebView:', error);
    }
  }

  function voltarMenu() {
    if (intervalRef.current) clearInterval(intervalRef.current);
    intervalRef.current = null;
    stopAllNativeSounds();
    setModo(null);
  }

  if (!modo) {
    return (
      <SafeAreaView style={styles.menuContainer}>
        <StatusBar barStyle="light-content" backgroundColor="#121212" />
        <ScrollView contentContainerStyle={styles.menuScroll}>
          <Text style={styles.menuTitle}>🏆 SportLink</Text>
          <Text style={styles.menuSub}>Escolha o modo de jogo</Text>
          <View style={styles.soundPanel}>
            <View style={styles.soundHeader}>
              <Text style={styles.soundTitle}>🔊 Áudio</Text>
              <TouchableOpacity style={[styles.muteBtn, muted && styles.muteBtnActive]} onPress={() => setMuted(!muted)}>
                <Text style={[styles.muteBtnText, muted && styles.muteBtnTextActive]}>{muted ? 'Mudo' : 'Ligado'}</Text>
              </TouchableOpacity>
            </View>
            <View style={styles.volumeRow}>
              <TouchableOpacity style={styles.volumeBtn} onPress={() => setVolume((v) => Math.max(0, +(v - 0.1).toFixed(1)))}><Text style={styles.volumeBtnText}>−</Text></TouchableOpacity>
              <View style={styles.volumeBar}><View style={[styles.volumeFill, { width: `${Math.round(volume * 100)}%` }]} /></View>
              <TouchableOpacity style={styles.volumeBtn} onPress={() => setVolume((v) => Math.min(1, +(v + 0.1).toFixed(1)))}><Text style={styles.volumeBtnText}>+</Text></TouchableOpacity>
            </View>
          </View>
          <View style={styles.rankPanel}>
            <View style={styles.rankHeader}><Text style={styles.rankTitle}>🏅 Ranking local</Text><TouchableOpacity onPress={resetRanking}><Text style={styles.rankReset}>zerar</Text></TouchableOpacity></View>
            <Text style={styles.rankLine}>Partidas: {ranking.jogos || 0}</Text>
            <Text style={styles.rankLine}>Vs IA — Você: {ranking.playerWins || 0} | IA: {ranking.aiWins || 0}</Text>
            <Text style={styles.rankLine}>2P — Verde: {ranking.verdeWins || 0} | Vermelho: {ranking.vermelhoWins || 0}</Text>
            <Text style={styles.rankLine}>Online — Vitórias: {ranking.onlineWins || 0} | Derrotas: {ranking.onlineLosses || 0}</Text>
          </View>
          <TouchableOpacity style={styles.modeCard} onPress={() => setModo('ai')}><Text style={styles.modeIcon}>🤖</Text><View style={styles.modeInfo}><Text style={styles.modeTitle}>1 Jogador — vs IA</Text><Text style={styles.modeSub}>Jogue contra o computador</Text></View><Text style={styles.modeArrow}>›</Text></TouchableOpacity>
          <View style={styles.diffRow}><Text style={styles.diffLabel}>Dificuldade da IA</Text><View style={styles.diffBtns}>{['facil', 'medio', 'dificil'].map((d) => <TouchableOpacity key={d} style={[styles.diffBtn, diff === d && styles.diffBtnActive]} onPress={() => setDiff(d)}><Text style={[styles.diffBtnText, diff === d && styles.diffBtnTextActive]}>{d === 'facil' ? 'Fácil' : d === 'medio' ? 'Médio' : 'Difícil'}</Text></TouchableOpacity>)}</View></View>
          <TouchableOpacity style={styles.modeCard} onPress={() => setModo('local')}><Text style={styles.modeIcon}>📱</Text><View style={styles.modeInfo}><Text style={styles.modeTitle}>2 Jogadores — Mesmo Celular</Text><Text style={styles.modeSub}>Cada um controla um lado da tela</Text></View><Text style={styles.modeArrow}>›</Text></TouchableOpacity>
          <View style={styles.onlinePanel}><Text style={styles.onlineTitle}>🌐 Online Supabase</Text><Text style={styles.onlineSub}>{onlineStatus}</Text><View style={styles.onlineRow}><TouchableOpacity style={styles.onlineBtn} onPress={criarSalaOnline}><Text style={styles.onlineBtnText}>Criar sala</Text></TouchableOpacity><TextInput value={codigoInput} onChangeText={(v) => setCodigoInput(v.toUpperCase())} placeholder="CÓDIGO" placeholderTextColor="#555" autoCapitalize="characters" style={styles.roomInput} /><TouchableOpacity style={styles.onlineBtn} onPress={entrarSalaOnline}><Text style={styles.onlineBtnText}>Entrar</Text></TouchableOpacity></View><Text style={styles.onlineHint}>Criador = Verde/host • Quem entra = Vermelho</Text></View>
        </ScrollView>
      </SafeAreaView>
    );
  }

  return <SafeAreaView style={styles.gameContainer}><StatusBar barStyle="light-content" hidden /><TouchableOpacity style={styles.btnVoltar} onPress={voltarMenu}><Text style={styles.btnVoltarText}>← Menu</Text></TouchableOpacity>{(modo === 'host' || modo === 'guest') && <View style={styles.roomBadge}><Text style={styles.roomBadgeText}>{codigoSala} • {modo === 'host' ? 'Verde' : 'Vermelho'}</Text></View>}<WebView ref={webviewRef} originWhitelist={['*']} source={{ html: buildHtml(modo, diff) }} style={{ flex: 1 }} scrollEnabled={false} bounces={false} allowsInlineMediaPlayback mediaPlaybackRequiresUserAction={false} onMessage={handleWebViewMessage} /></SafeAreaView>;
}

function buildHtml(modo, diff) {
  return `<!DOCTYPE html><html><head><meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"><style>html,body{margin:0;padding:0;overflow:hidden;background:#121212;touch-action:none;font-family:Arial}canvas{display:block}#hud{position:fixed;top:0;left:0;right:0;display:flex;justify-content:space-between;padding:6px 64px 6px 20px;z-index:10;pointer-events:none}.score{font-size:28px;font-weight:bold}#hud-mode{font-size:10px;color:#777}#pause-btn{position:fixed;top:8px;right:14px;z-index:30;width:42px;height:34px;border-radius:18px;background:rgba(0,0,0,.45);color:white;border:1px solid #444}#overlay{position:fixed;inset:0;background:rgba(0,0,0,.72);z-index:20;color:white;display:flex;align-items:center;justify-content:center;flex-direction:column;text-align:center}#overlay.hidden{display:none}#overlay-title{font-size:22px;font-weight:bold}#overlay-sub{font-size:13px;color:#888;margin-top:12px}#overlay-gol{font-size:44px;font-weight:bold}</style></head><body><div id="hud"><div class="score" id="sc2" style="color:#E74C3C">0</div><div id="hud-mode">${modo === 'ai' ? 'IA • ' + diff : modo === 'local' ? '2P LOCAL' : 'ONLINE'}</div><div class="score" id="sc1" style="color:#00FF66">0</div></div><button id="pause-btn">⏸</button><canvas id="c"></canvas><div id="overlay"><div id="overlay-title">${modo === 'ai' ? '🤖 vs IA' : modo === 'local' ? '👥 2 Jogadores' : modo === 'host' ? '🟢 Online Verde' : '🔴 Online Vermelho'}</div><div id="overlay-sub">Toque para começar • bola parada no centro</div><div id="overlay-gol" style="display:none"></div></div><script>
const GAME_MODE='${modo}',AI_DIFF='${diff}',WIN_SCORE=5,IS_ONLINE=GAME_MODE==='host'||GAME_MODE==='guest';let lastSoundAt=0,resultSent=false,lastOnlineSend=0;function sendNativeMessage(p){try{window.ReactNativeWebView.postMessage(JSON.stringify(p))}catch(e){}}function playSound(name){const now=Date.now();if(name!=='gol'&&name!=='torcida'&&now-lastSoundAt<45)return;lastSoundAt=now;sendNativeMessage({type:'sound',name})}function vibrate(duration){sendNativeMessage({type:'vibrate',duration})}function sendGameOver(winner){if(resultSent)return;resultSent=true;sendNativeMessage({type:'gameOver',mode:GAME_MODE,diff:AI_DIFF,winner,sc1,sc2})}function sendOnlineState(force){if(!IS_ONLINE)return;const now=Date.now();if(!force&&now-lastOnlineSend<70)return;lastOnlineSend=now;sendNativeMessage({type:'estado',estado:normalizeState()})}
const canvas=document.getElementById('c'),ctx=canvas.getContext('2d');canvas.width=innerWidth;canvas.height=innerHeight;const W=canvas.width,H=canvas.height,GT=50,GB=H-50,GH=GB-GT,MID=GT+GH/2,BR=16,PR=26;let ball={x:W/2,y:MID,vx:0,vy:0},p1={x:W/2,y:GB-70},p2={x:W/2,y:GT+70},sc1=0,sc2=0,running=false,paused=false,gameOver=false,winner=null,goalFlash=0;function normalizeState(){return{ball:{x:ball.x/W,y:ball.y/H,vx:ball.vx/W,vy:ball.vy/H},p1:{x:p1.x/W,y:p1.y/H},p2:{x:p2.x/W,y:p2.y/H},sc1,sc2,running,paused,gameOver,winner}}window.receiveOnlineState=function(s){if(!s)return;if(GAME_MODE==='guest'){if(s.ball){ball.x=s.ball.x*W;ball.y=s.ball.y*H;ball.vx=s.ball.vx*W;ball.vy=s.ball.vy*H}if(s.p1){p1.x=s.p1.x*W;p1.y=s.p1.y*H}sc1=s.sc1||0;sc2=s.sc2||0;running=!!s.running;paused=!!s.paused;gameOver=!!s.gameOver;winner=s.winner}else if(GAME_MODE==='host'&&s.p2){p2.x=s.p2.x*W;p2.y=s.p2.y*H}if(running&&!paused&&!gameOver)document.getElementById('overlay').classList.add('hidden');if(gameOver&&winner)endGame(winner,true)};
let activeTouches={};function clamp(v,a,b){return Math.max(a,Math.min(b,v))}function getTouchPlayer(y){if(GAME_MODE==='host')return'p1';if(GAME_MODE==='guest')return'p2';return y>MID?'p1':'p2'}addEventListener('touchstart',e=>{for(const t of e.changedTouches){activeTouches[t.identifier]={x:t.clientX,y:t.clientY,player:GAME_MODE==='ai'?'p1':getTouchPlayer(t.clientY)}}updatePaddles(true)},{passive:true});addEventListener('touchmove',e=>{e.preventDefault();for(const t of e.changedTouches){const touch=activeTouches[t.identifier];if(!touch)continue;if(GAME_MODE==='local'&&getTouchPlayer(t.clientY)!==touch.player){delete activeTouches[t.identifier];continue}touch.x=t.clientX;touch.y=t.clientY}updatePaddles(true)},{passive:false});addEventListener('touchend',e=>{for(const t of e.changedTouches)delete activeTouches[t.identifier]});
const AI_CFG={facil:{speed:2.2,errX:65,react:GH*.30,predic:.10},medio:{speed:3.8,errX:28,react:GH*.55,predic:.45},dificil:{speed:6.2,errX:6,react:GH*.90,predic:.85}};let aiErr=0,aiTgt={x:W/2,y:GT+70};function recalcAIErr(){aiErr=(Math.random()*2-1)*AI_CFG[AI_DIFF].errX}recalcAIErr();function stepAI(){const cfg=AI_CFG[AI_DIFF],b=ball,bs=Math.hypot(b.vx,b.vy),inAI=b.y<MID-BR;if(inAI&&(bs<1.8||b.vy>=-.2)){aiTgt.x=b.x+aiErr*.2;aiTgt.y=b.y-(BR+PR-4)}else if(b.vy<0&&Math.abs(p2.y-b.y)<cfg.react){const steps=Math.max(1,Math.abs(p2.y-b.y)/Math.max(.1,Math.abs(b.vy)));aiTgt.x=b.x+b.vx*steps*cfg.predic+aiErr;aiTgt.y=GT+70}else{aiTgt.x=W/2;aiTgt.y=GT+70}aiTgt.x=clamp(aiTgt.x,PR,W-PR);aiTgt.y=clamp(aiTgt.y,GT+PR,MID-PR);const dx=aiTgt.x-p2.x,dy=aiTgt.y-p2.y,d=Math.hypot(dx,dy);if(d>.5){const mv=Math.min(cfg.speed,d);p2.x+=dx/d*mv;p2.y+=dy/d*mv}}
function updatePaddles(send){for(const id in activeTouches){const t=activeTouches[id];if(GAME_MODE==='local'||IS_ONLINE){if(t.player==='p1'){p1.x=t.x;p1.y=t.y}else{p2.x=t.x;p2.y=t.y}}else{p1.x=t.x;p1.y=t.y}}p1.x=clamp(p1.x,PR,W-PR);p1.y=clamp(p1.y,MID+PR,GB-PR);p2.x=clamp(p2.x,PR,W-PR);p2.y=clamp(p2.y,GT+PR,MID-PR);if(send)sendOnlineState(false)}function colide(p){const dx=ball.x-p.x,dy=ball.y-p.y,d=Math.hypot(dx,dy),mn=BR+PR;if(d<mn&&d>0){playSound('chute');vibrate(22);const nx=dx/d,ny=dy/d;ball.x=p.x+nx*mn;ball.y=p.y+ny*mn;ball.vx=nx*9;ball.vy=ny*9;sendOnlineState(true)}}function goal(w){w==='p1'?sc1++:sc2++;showGoal(w==='p1'?'#00FF66':'#E74C3C');if((w==='p1'?sc1:sc2)>=WIN_SCORE)endGame(w);else resetBall()}function updatePhysics(){if(GAME_MODE==='guest')return;if(GAME_MODE==='ai')stepAI();ball.x+=ball.vx;ball.y+=ball.vy;ball.vx*=.985;ball.vy*=.985;if(Math.abs(ball.vx)<.04)ball.vx=0;if(Math.abs(ball.vy)<.04)ball.vy=0;const gL=W*.25,gR=W*.75;if(ball.x-BR<0){ball.x=BR;ball.vx=Math.abs(ball.vx)*.9;playSound('trave')}if(ball.x+BR>W){ball.x=W-BR;ball.vx=-Math.abs(ball.vx)*.9;playSound('trave')}if(ball.y-BR<GT){ball.x>gL&&ball.x<gR?goal('p1'):(ball.y=GT+BR,ball.vy=Math.abs(ball.vy)*.9,playSound('trave'))}if(ball.y+BR>GB){ball.x>gL&&ball.x<gR?goal('p2'):(ball.y=GB-BR,ball.vy=-Math.abs(ball.vy)*.9,playSound('trave'))}colide(p1);colide(p2);sendOnlineState(false)}function resetBall(){ball={x:W/2,y:MID,vx:0,vy:0};setTimeout(()=>{if(!gameOver&&running)playSound('apito')},900);sendOnlineState(true)}function showGoal(cor){playSound('gol');vibrate(140);goalFlash=30;const el=document.getElementById('overlay-gol');el.textContent='GOL! ⚽';el.style.color=cor;el.style.display='block';const ov=document.getElementById('overlay');ov.classList.remove('hidden');setTimeout(()=>{if(!gameOver&&!paused){ov.classList.add('hidden');el.style.display='none'}},1200)}function endGame(w,remote){gameOver=true;winner=w;ball.vx=0;ball.vy=0;if(!remote)sendGameOver(w);sendOnlineState(true);document.getElementById('overlay-title').textContent=w==='p1'?'🏆 Verde venceu!':'🏆 Vermelho venceu!';document.getElementById('overlay-sub').textContent='Placar final: '+sc1+' x '+sc2+' • toque para jogar novamente';document.getElementById('overlay').classList.remove('hidden')}function restartMatch(){sc1=0;sc2=0;gameOver=false;winner=null;resultSent=false;p1={x:W/2,y:GB-70};p2={x:W/2,y:GT+70};resetBall();document.getElementById('overlay').classList.add('hidden')}function setPaused(v){if(!running||gameOver)return;paused=v;document.getElementById('pause-btn').textContent=paused?'▶':'⏸';paused?document.getElementById('overlay').classList.remove('hidden'):document.getElementById('overlay').classList.add('hidden');sendOnlineState(true)}
function drawNet(x1,y1,x2,y2){ctx.save();ctx.strokeStyle='rgba(255,255,255,.28)';ctx.lineWidth=1;for(let x=x1;x<=x2;x+=12){ctx.beginPath();ctx.moveTo(x,y1);ctx.lineTo(x,y2);ctx.stroke()}const yMin=Math.min(y1,y2),yMax=Math.max(y1,y2);for(let y=yMin;y<=yMax;y+=8){ctx.beginPath();ctx.moveTo(x1,y);ctx.lineTo(x2,y);ctx.stroke()}ctx.restore()}function drawPentagon(cx,cy,rad,rot){ctx.beginPath();for(let i=0;i<5;i++){const a=rot+i*Math.PI*2/5,px=cx+Math.cos(a)*rad,py=cy+Math.sin(a)*rad;i?ctx.lineTo(px,py):ctx.moveTo(px,py)}ctx.closePath();ctx.fill();ctx.stroke()}function drawBall(x,y,r){ctx.save();ctx.translate(x,y);ctx.fillStyle='#FFF';ctx.beginPath();ctx.arc(0,0,r,0,Math.PI*2);ctx.fill();ctx.clip();ctx.strokeStyle='#111';ctx.lineWidth=1.4;ctx.fillStyle='#111';drawPentagon(0,0,r*.34,-Math.PI/2);[[-.55,-.55],[.55,-.55],[-.62,.48],[.62,.48],[0,.78]].forEach((p,i)=>{const sx=p[0]*r,sy=p[1]*r;drawPentagon(sx,sy,r*.22,-Math.PI/2+i*.25);ctx.beginPath();ctx.moveTo(0,0);ctx.lineTo(sx,sy);ctx.stroke()});ctx.strokeStyle='#000';ctx.lineWidth=2;ctx.beginPath();ctx.arc(0,0,r-1,0,Math.PI*2);ctx.stroke();ctx.restore()}function drawPlayer(x,y,color,num,flip){const s=1.15;ctx.save();ctx.translate(x,y);if(flip)ctx.scale(1,-1);ctx.beginPath();ctx.ellipse(0,28*s,14*s,4*s,0,0,Math.PI*2);ctx.fillStyle='rgba(0,0,0,.3)';ctx.fill();ctx.fillStyle='#1a1a2e';ctx.fillRect(-9*s,12*s,7*s,13*s);ctx.fillRect(2*s,12*s,7*s,13*s);ctx.fillStyle=color;ctx.fillRect(-9*s,18*s,7*s,6*s);ctx.fillRect(2*s,18*s,7*s,6*s);ctx.fillStyle='#1a1a2e';ctx.fillRect(-10*s,9*s,20*s,6*s);ctx.save();ctx.translate(-11*s,0);ctx.rotate(.55);ctx.fillStyle=color;ctx.fillRect(-3.5*s,0,7*s,10*s);ctx.fillStyle='#e8b89a';ctx.fillRect(-3*s,9.5*s,6*s,8*s);ctx.beginPath();ctx.ellipse(0,17.5*s,3.5*s,3*s,0,0,Math.PI*2);ctx.fill();ctx.restore();ctx.save();ctx.translate(11*s,0);ctx.rotate(-.55);ctx.fillStyle=color;ctx.fillRect(-3.5*s,0,7*s,10*s);ctx.fillStyle='#e8b89a';ctx.fillRect(-3*s,9.5*s,6*s,8*s);ctx.beginPath();ctx.ellipse(0,17.5*s,3.5*s,3*s,0,0,Math.PI*2);ctx.fill();ctx.restore();ctx.fillStyle=color;ctx.beginPath();ctx.roundRect(-11*s,-4*s,22*s,15*s,3*s);ctx.fill();ctx.fillStyle=color==='#00FF66'?'#121212':'#fff';ctx.font='bold '+Math.round(8*s)+'px Arial';ctx.textAlign='center';ctx.fillText(num,0,7*s);ctx.fillStyle='#e8b89a';ctx.fillRect(-3*s,-10*s,6*s,8*s);ctx.beginPath();ctx.ellipse(0,-17*s,11*s,12*s,0,0,Math.PI*2);ctx.fill();ctx.fillStyle=color==='#00FF66'?'#1a1a1a':'#5c1a00';ctx.beginPath();ctx.ellipse(0,-24*s,11*s,7*s,0,0,Math.PI);ctx.fill();ctx.fillStyle='#222';ctx.beginPath();ctx.ellipse(-3.5*s,-17.5*s,2*s,2.5*s,0,0,Math.PI*2);ctx.ellipse(3.5*s,-17.5*s,2*s,2.5*s,0,0,Math.PI*2);ctx.fill();ctx.restore()}function draw(){ctx.clearRect(0,0,W,H);ctx.fillStyle='#121212';ctx.fillRect(0,0,W,H);ctx.fillStyle='#1E3F20';ctx.fillRect(0,GT,W,GH);ctx.strokeStyle='rgba(255,255,255,.28)';ctx.lineWidth=4;ctx.strokeRect(0,GT,W,GH);ctx.beginPath();ctx.moveTo(0,MID);ctx.lineTo(W,MID);ctx.stroke();ctx.beginPath();ctx.arc(W/2,MID,60,0,Math.PI*2);ctx.stroke();const gL=W*.25,gR=W*.75,nH=25;ctx.strokeStyle='#FFF';ctx.lineWidth=6;ctx.beginPath();ctx.moveTo(gL,GT);ctx.lineTo(gL,GT-nH);ctx.lineTo(gR,GT-nH);ctx.lineTo(gR,GT);ctx.moveTo(gL,GB);ctx.lineTo(gL,GB+nH);ctx.lineTo(gR,GB+nH);ctx.lineTo(gR,GB);ctx.stroke();drawNet(gL,GT-nH,gR,GT);drawNet(gL,GB,gR,GB+nH);document.getElementById('sc1').textContent=sc1;document.getElementById('sc2').textContent=sc2;drawBall(ball.x,ball.y,BR);drawPlayer(p1.x,p1.y,'#00FF66','1',false);drawPlayer(p2.x,p2.y,'#E74C3C',GAME_MODE==='ai'?'IA':'2',true)}function loop(){if(running&&!paused&&!gameOver){updatePaddles(false);updatePhysics()}draw();requestAnimationFrame(loop)}const overlay=document.getElementById('overlay');function startMatch(){overlay.classList.add('hidden');playSound('torcida');playSound('apito');ball={x:W/2,y:MID,vx:0,vy:0};running=true;paused=false;gameOver=false;sendOnlineState(true)}overlay.addEventListener('touchstart',()=>{if(!running){startMatch();return}if(gameOver){restartMatch();return}if(paused)setPaused(false)});document.getElementById('pause-btn').addEventListener('click',()=>setPaused(!paused));loop();
</script></body></html>`;
}
