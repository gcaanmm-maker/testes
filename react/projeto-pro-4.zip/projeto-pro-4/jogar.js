import React, { useCallback, useEffect, useState } from 'react';
import { Alert, FlatList, RefreshControl, SafeAreaView, ScrollView, Text, TextInput, TouchableOpacity, View } from 'react-native';
import MapView, { Marker } from 'react-native-maps';
import styles from './styles';
import { supabase, MONTES_CLAROS_REGION, PELADAS_MOCK } from './supabase';

export default function JogarScreen({ usuarioLogado }) {
  const [abaAtiva, setAbaAtiva] = useState('Encontrar');
  const [partidas, setPartidas] = useState([]);
  const [refreshing, setRefreshing] = useState(false);
  const [nomeQuadra, setNomeQuadra] = useState('');
  const [endereco, setEndereco] = useState('');
  const [dataHora, setDataHora] = useState('');
  const [jogadores, setJogadores] = useState('');
  const [goleiros, setGoleiros] = useState('');
  const [valor, setValor] = useState('');

  const listar = useCallback(async () => {
    const { data } = await supabase.from('partidas').select('*');
    setPartidas([...PELADAS_MOCK, ...(data || [])]);
  }, []);

  useEffect(() => { listar(); }, [listar]);
  const onRefresh = async () => { setRefreshing(true); await listar(); setRefreshing(false); };

  const criar = async () => {
    if (!usuarioLogado) return Alert.alert('Aviso', 'Faça login no Bolão primeiro.');
    if (!nomeQuadra || !endereco || !dataHora || !jogadores || !goleiros || !valor) return Alert.alert('Atenção', 'Preencha todos os campos.');
    const lat = -16.7291552 + (Math.random() - 0.5) * 0.03;
    const lng = -43.8670745 + (Math.random() - 0.5) * 0.03;
    const { error } = await supabase.from('partidas').insert([{ nome_quadra: nomeQuadra, endereco, data_hora: dataHora, jogadores: parseInt(jogadores, 10), goleiros: parseInt(goleiros, 10), valor, latitude: lat, longitude: lng, criador_id: usuarioLogado.id }]);
    if (!error) { Alert.alert('Sucesso', 'Pelada cadastrada!'); setNomeQuadra(''); setEndereco(''); setDataHora(''); setJogadores(''); setGoleiros(''); setValor(''); setAbaAtiva('Encontrar'); listar(); }
  };

  return <SafeAreaView style={styles.container}><View style={styles.subTabsContainer}>{['Encontrar', 'Criar Partida'].map((tab) => <TouchableOpacity key={tab} style={[styles.subTabItem, abaAtiva === tab && styles.subTabItemActive]} onPress={() => setAbaAtiva(tab)}><Text style={[styles.subTabItemText, abaAtiva === tab && styles.subTabItemTextActive]}>{tab}</Text></TouchableOpacity>)}</View>{abaAtiva === 'Encontrar' ? <View style={{ flex: 1 }}><View style={styles.mapContainer}><MapView style={styles.map} initialRegion={MONTES_CLAROS_REGION}>{partidas.map((p, i) => <Marker key={i} coordinate={{ latitude: p.latitude, longitude: p.longitude }} title={p.nome_quadra} pinColor="#00FF66" />)}</MapView></View><FlatList data={partidas} keyExtractor={(item, index) => String(item.id || index)} refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor="#00FF66" />} renderItem={({ item }) => <View style={styles.peladaCard}><View style={styles.peladaInfo}><Text style={styles.peladaCardTitle}>{item.nome_quadra}</Text><Text style={styles.peladaCardSub}>📍 {item.endereco}</Text><Text style={{ color: '#888', fontSize: 12 }}>⏰ {item.data_hora}</Text></View><TouchableOpacity style={styles.btnParticipar}><Text style={styles.btnParticiparText}>{item.combinada ? 'Disponível' : 'Pedir Vaga'}</Text></TouchableOpacity></View>} /></View> : <ScrollView contentContainerStyle={{ padding: 20 }}><TextInput style={styles.authInput} placeholder="Nome da Quadra" placeholderTextColor="#888" value={nomeQuadra} onChangeText={setNomeQuadra} /><TextInput style={styles.authInput} placeholder="Endereço" placeholderTextColor="#888" value={endereco} onChangeText={setEndereco} /><TextInput style={styles.authInput} placeholder="Horário" placeholderTextColor="#888" value={dataHora} onChangeText={setDataHora} /><TextInput style={styles.authInput} placeholder="Vagas Linha" placeholderTextColor="#888" keyboardType="numeric" value={jogadores} onChangeText={setJogadores} /><TextInput style={styles.authInput} placeholder="Vagas Goleiro" placeholderTextColor="#888" keyboardType="numeric" value={goleiros} onChangeText={setGoleiros} /><TextInput style={styles.authInput} placeholder="Valor" placeholderTextColor="#888" value={valor} onChangeText={setValor} /><TouchableOpacity style={styles.authButton} onPress={criar}><Text style={styles.authButtonText}>Publicar no Mapa</Text></TouchableOpacity></ScrollView>}</SafeAreaView>;
}
