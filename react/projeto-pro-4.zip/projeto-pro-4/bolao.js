import React, { useCallback, useEffect, useState } from 'react';
import { Alert, FlatList, KeyboardAvoidingView, Modal, Platform, RefreshControl, SafeAreaView, ScrollView, Text, TextInput, TouchableOpacity, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import styles from './styles';
import { supabase, FOOTBALL_DATA_TOKEN, getFlagEmoji } from './supabase';

export default function BolaoScreen({ usuarioLogado, setUsuarioLogado }) {
  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');
  const [isLoginView, setIsLoginView] = useState(true);
  const [modalGrupoVisible, setModalGrupoVisible] = useState(false);
  const [meusGrupos, setMeusGrupos] = useState([]);
  const [grupoUsuario, setGrupoUsuario] = useState(null);
  const [nomeGrupoInput, setNomeGrupoInput] = useState('');
  const [codigoGrupoInput, setCodigoGrupoInput] = useState('');
  const [jogosApi, setJogosApi] = useState([]);
  const [palpites, setPalpites] = useState({});
  const [ranking, setRanking] = useState([]);
  const [abaInterna, setAbaInterna] = useState('Meus Palpites');
  const [refreshing, setRefreshing] = useState(false);

  const handleCadastro = async () => {
    if (!email || !senha) return Alert.alert('Atenção', 'Preencha todos os campos!');
    const { error } = await supabase.from('usuarios').insert([{ email, senha }]);
    if (error) Alert.alert('Erro', 'Este email já está em uso.');
    else { Alert.alert('Sucesso', 'Conta criada! Faça login.'); setIsLoginView(true); setSenha(''); }
  };

  const handleLogin = async () => {
    if (!email || !senha) return Alert.alert('Atenção', 'Preencha todos os campos!');
    const { data } = await supabase.from('usuarios').select('*').eq('email', email).eq('senha', senha).maybeSingle();
    if (data) { setUsuarioLogado(data); setEmail(''); setSenha(''); }
    else Alert.alert('Erro', 'Credenciais inválidas!');
  };

  const carregarGrupos = useCallback(async () => {
    if (!usuarioLogado) return;
    const { data } = await supabase.from('grupo_membros').select('status, grupos ( id, nome, codigo_acesso, tipo, criador_id )').eq('usuario_id', usuarioLogado.id);
    const grupos = (data || []).map((item) => ({ ...item.grupos, statusMembro: item.status }));
    setMeusGrupos(grupos);
    if (!grupoUsuario && grupos.length) setGrupoUsuario(grupos[0]);
  }, [usuarioLogado, grupoUsuario]);

  const fetchJogosBolaoApi = async () => {
    try {
      const res = await fetch('https://api.football-data.org/v4/competitions/WC/matches?status=SCHEDULED', { headers: { 'X-Auth-Token': FOOTBALL_DATA_TOKEN } });
      const data = await res.json();
      if (data.matches) setJogosApi(data.matches);
    } catch (e) { console.error(e); }
  };

  const carregarRanking = useCallback(async () => {
    if (!grupoUsuario) return;
    const { data } = await supabase.from('grupo_membros').select('usuario_id, usuarios:usuario_id ( email )').eq('grupo_id', grupoUsuario.id);
    setRanking((data || []).map((m) => ({ id: m.usuario_id, email: m.usuarios?.email || 'Usuário', pontos: (String(m.usuario_id).length % 7) * 20 + 50 })).sort((a, b) => b.pontos - a.pontos));
  }, [grupoUsuario]);

  useEffect(() => { if (usuarioLogado) { carregarGrupos(); fetchJogosBolaoApi(); } }, [usuarioLogado, carregarGrupos]);
  useEffect(() => { carregarRanking(); }, [carregarRanking]);
  const onRefresh = async () => { setRefreshing(true); await carregarGrupos(); await fetchJogosBolaoApi(); await carregarRanking(); setRefreshing(false); };

  const handleCriarGrupo = async () => {
    if (!nomeGrupoInput) return Alert.alert('Atenção', 'Preencha o nome do grupo!');
    const codigoAcesso = Math.floor(100000 + Math.random() * 900000).toString();
    const { data } = await supabase.from('grupos').insert([{ nome: nomeGrupoInput, codigo_acesso: codigoAcesso, criador_id: usuarioLogado.id }]).select().single();
    if (data) { await supabase.from('grupo_membros').insert([{ grupo_id: data.id, usuario_id: usuarioLogado.id, status: 'aprovado' }]); Alert.alert('Grupo Criado!', `Código: ${codigoAcesso}`); setGrupoUsuario(data); setNomeGrupoInput(''); setModalGrupoVisible(false); carregarGrupos(); }
  };

  const handleEntrarGrupo = async () => {
    const codigo = codigoGrupoInput.trim();
    if (!codigo) return Alert.alert('Atenção', 'Digite o código!');
    const { data: grupo } = await supabase.from('grupos').select('*').eq('codigo_acesso', codigo).maybeSingle();
    if (!grupo) return Alert.alert('Erro', 'Grupo não encontrado.');
    await supabase.from('grupo_membros').upsert({ grupo_id: grupo.id, usuario_id: usuarioLogado.id, status: 'aprovado' });
    Alert.alert('Sucesso', `Entrou no grupo ${grupo.nome}`); setGrupoUsuario(grupo); setCodigoGrupoInput(''); setModalGrupoVisible(false); carregarGrupos();
  };

  const atualizarPalpite = (jogoId, time, valor) => setPalpites((prev) => ({ ...prev, [jogoId]: { ...prev[jogoId], [time]: valor } }));
  const salvarPalpite = async (jogo) => {
    if (!grupoUsuario) return Alert.alert('Atenção', 'Crie ou entre em um grupo primeiro.');
    const palpite = palpites[jogo.id] || {};
    if (!palpite.p1 || !palpite.p2) return Alert.alert('Atenção', 'Preencha os dois placares.');
    const nomeJogoStr = `${jogo.homeTeam.name} x ${jogo.awayTeam.name}`;
    const { error } = await supabase.from('bolao').upsert({ id: jogo.id.toString(), usuario_id: usuarioLogado.id, grupo_id: grupoUsuario.id, jogo: nomeJogoStr, placar_time1: palpite.p1, placar_time2: palpite.p2 });
    if (!error) Alert.alert('Sucesso', 'Palpite salvo!');
  };

  if (!usuarioLogado) {
    return <SafeAreaView style={styles.container}><KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={styles.authContainer}><Ionicons name="trophy" size={70} color="#00FF66" /><Text style={styles.authTitle}>{isLoginView ? 'Pronto para o Bolão?' : 'Crie sua conta'}</Text><TextInput style={styles.authInput} placeholder="E-mail" placeholderTextColor="#888" value={email} onChangeText={setEmail} autoCapitalize="none" /><TextInput style={styles.authInput} placeholder="Senha" placeholderTextColor="#888" secureTextEntry value={senha} onChangeText={setSenha} /><TouchableOpacity style={styles.authButton} onPress={isLoginView ? handleLogin : handleCadastro}><Text style={styles.authButtonText}>{isLoginView ? 'Entrar' : 'Cadastrar'}</Text></TouchableOpacity><TouchableOpacity style={{ marginTop: 25 }} onPress={() => setIsLoginView(!isLoginView)}><Text style={styles.authToggleText}>{isLoginView ? 'Não tem conta? Crie aqui.' : 'Já tem conta? Faça login.'}</Text></TouchableOpacity></KeyboardAvoidingView></SafeAreaView>;
  }

  return <SafeAreaView style={styles.container}><View style={styles.header}><TouchableOpacity style={styles.btnMeusGruposTop} onPress={() => setModalGrupoVisible(true)}><Ionicons name="apps" size={18} color="#00FF66" /><Text style={styles.btnMeusGruposTopTxt}>Grupos</Text></TouchableOpacity><Text style={styles.headerTitleCenter}>🎯 {grupoUsuario?.nome || 'Bolão'}</Text><TouchableOpacity style={styles.logoutIcon} onPress={() => { setUsuarioLogado(null); setGrupoUsuario(null); }}><Ionicons name="log-out-outline" size={24} color="#E74C3C" /></TouchableOpacity></View><View style={styles.subTabsContainer}>{['Meus Palpites', 'Ranking'].map((tab) => <TouchableOpacity key={tab} style={[styles.subTabItem, abaInterna === tab && styles.subTabItemActive]} onPress={() => setAbaInterna(tab)}><Text style={[styles.subTabItemText, abaInterna === tab && styles.subTabItemTextActive]}>{tab}</Text></TouchableOpacity>)}</View>{abaInterna === 'Ranking' ? <FlatList data={ranking} keyExtractor={(item, index) => String(item.id || index)} refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor="#00FF66" />} contentContainerStyle={styles.scrollContainer} renderItem={({ item, index }) => <View style={styles.rankingRow}><Text style={styles.rankingPos}>{index + 1}º</Text><Text style={styles.rankingEmail}>{item.email}</Text><Text style={styles.rankingPoints}>{item.pontos} pts</Text></View>} /> : <FlatList data={jogosApi} keyExtractor={(item) => item.id.toString()} refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor="#00FF66" />} contentContainerStyle={styles.scrollContainer} ListEmptyComponent={<Text style={styles.emptyText}>Nenhum jogo carregado.</Text>} renderItem={({ item }) => { const p1 = palpites[item.id]?.p1 || ''; const p2 = palpites[item.id]?.p2 || ''; return <View style={styles.betCard}><Text style={styles.betMatchName}>{new Date(item.utcDate).toLocaleDateString('pt-BR')}</Text><View style={styles.matchRow}><View style={styles.teamContainer}><Text style={styles.teamFlag}>{getFlagEmoji(item.homeTeam.tla)}</Text><Text style={styles.teamName}>{item.homeTeam.tla || item.homeTeam.name}</Text></View><View style={styles.scoreRow}><TextInput style={styles.scoreInput} keyboardType="numeric" value={p1} onChangeText={(v) => atualizarPalpite(item.id, 'p1', v)} /><Text style={styles.xText}>X</Text><TextInput style={styles.scoreInput} keyboardType="numeric" value={p2} onChangeText={(v) => atualizarPalpite(item.id, 'p2', v)} /></View><View style={styles.teamContainer}><Text style={styles.teamFlag}>{getFlagEmoji(item.awayTeam.tla)}</Text><Text style={styles.teamName}>{item.awayTeam.tla || item.awayTeam.name}</Text></View></View><TouchableOpacity style={styles.btnConfirmar} onPress={() => salvarPalpite(item)}><Text style={styles.btnConfirmarText}>Salvar Palpite</Text></TouchableOpacity></View>; }} />}<Modal visible={modalGrupoVisible} animationType="slide" onRequestClose={() => setModalGrupoVisible(false)}><SafeAreaView style={styles.modalContainer}><View style={styles.modalHeader}><TouchableOpacity style={styles.btnFecharModal} onPress={() => setModalGrupoVisible(false)}><Ionicons name="arrow-back" size={24} color="#00FF66" /><Text style={styles.btnFecharModalText}>Voltar</Text></TouchableOpacity></View><ScrollView contentContainerStyle={{ padding: 20 }}><Text style={styles.sectionTitle}>Meus grupos</Text>{meusGrupos.map((g) => <TouchableOpacity key={g.id} style={[styles.grupoSelectorCard, grupoUsuario?.id === g.id && styles.grupoSelectorCardActive]} onPress={() => { setGrupoUsuario(g); setModalGrupoVisible(false); }}><Ionicons name="football" size={22} color={grupoUsuario?.id === g.id ? '#121212' : '#00FF66'} /><Text style={[styles.grupoSelectorCardTxt, grupoUsuario?.id === g.id && styles.grupoSelectorCardTxtActive]}>{g.nome}</Text></TouchableOpacity>)}<View style={styles.separator} /><Text style={styles.sectionTitle}>Criar grupo</Text><TextInput style={styles.authInput} placeholder="Nome do grupo" placeholderTextColor="#888" value={nomeGrupoInput} onChangeText={setNomeGrupoInput} /><TouchableOpacity style={styles.authButton} onPress={handleCriarGrupo}><Text style={styles.authButtonText}>Criar</Text></TouchableOpacity><View style={styles.separator} /><Text style={styles.sectionTitle}>Entrar com código</Text><TextInput style={styles.authInput} keyboardType="numeric" placeholder="Código" placeholderTextColor="#888" value={codigoGrupoInput} onChangeText={setCodigoGrupoInput} /><TouchableOpacity style={styles.authButton} onPress={handleEntrarGrupo}><Text style={styles.authButtonText}>Entrar</Text></TouchableOpacity></ScrollView></SafeAreaView></Modal></SafeAreaView>;
}
