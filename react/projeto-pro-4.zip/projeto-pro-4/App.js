import React, { useState } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Ionicons } from '@expo/vector-icons';

import NoticiasScreen from './noticias';
import BolaoScreen from './bolao';
import JogarScreen from './jogar';
import JoguinhoScreen from './joguinho';

const Tab = createBottomTabNavigator();

export default function App() {
  const [usuarioLogado, setUsuarioLogado] = useState(null);

  return (
    <NavigationContainer>
      <Tab.Navigator
        screenOptions={({ route }) => ({
          headerShown: false,
          tabBarStyle: { backgroundColor: '#1E1E1E', borderTopWidth: 0, height: 85, paddingBottom: 25 },
          tabBarActiveTintColor: '#00FF66',
          tabBarInactiveTintColor: '#888',
          tabBarIcon: ({ focused, color, size }) => {
            let iconName = route.name === 'Notícias' ? 'newspaper' : route.name === 'Bolão' ? 'trophy' : route.name === 'Jogar' ? 'map' : 'game-controller';
            if (!focused) iconName += '-outline';
            return <Ionicons name={iconName} size={size} color={color} />;
          },
        })}
      >
        <Tab.Screen name="Notícias" component={NoticiasScreen} />
        <Tab.Screen name="Bolão">{() => <BolaoScreen usuarioLogado={usuarioLogado} setUsuarioLogado={setUsuarioLogado} />}</Tab.Screen>
        <Tab.Screen name="Jogar">{() => <JogarScreen usuarioLogado={usuarioLogado} />}</Tab.Screen>
        <Tab.Screen name="Joguinho" component={JoguinhoScreen} />
      </Tab.Navigator>
    </NavigationContainer>
  );
}
