import { createClient } from '@supabase/supabase-js';

export const SUPABASE_URL = 'https://bqfbkkzcvlygwnvblgna.supabase.co';
export const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImJxZmJra3pjdmx5Z3dudmJsZ25hIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODI1MDc1NTQsImV4cCI6MjA5ODA4MzU1NH0.KA5KqUJ-j3iTeUIxvXXe4M9a-TBQz1-6fxD_uZ109fM';
export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

export const NEWS_API_KEY = 'f2865e181e304fba98fc039cbe68b232';
export const FOOTBALL_DATA_TOKEN = 'b0b0b4f4320d4a3694b56126429a520c';

export const MONTES_CLAROS_REGION = {
  latitude: -16.7291552,
  longitude: -43.8670745,
  latitudeDelta: 0.05,
  longitudeDelta: 0.05,
};

export const PELADAS_MOCK = [
  { id: 991, nome_quadra: 'Arena Todos os Santos', endereco: 'Bairro Todos os Santos, Montes Claros', data_hora: 'Sábado às 16:00', jogadores: 6, goleiros: 2, valor: 'R$ 20', latitude: -16.7235, longitude: -43.8590, combinada: true },
  { id: 992, nome_quadra: 'Society Major Prates', endereco: 'Bairro Major Prates, Montes Claros', data_hora: 'Terça às 20:30', jogadores: 4, goleiros: 1, valor: 'R$ 25', latitude: -16.7510, longitude: -43.8645, combinada: true },
];

export const FILTROS_NOTICIAS = [
  { id: '1', label: 'Tudo', query: 'Copa do Mundo 2026' },
  { id: '2', label: 'Brasil', query: 'Seleção Brasileira Copa 2026' },
  { id: '3', label: 'Bastidores', query: 'Copa do Mundo bastidores curiosidades' },
];

export const getFlagEmoji = (tla) => {
  if (!tla) return '🏳️';
  const flags = {
    BRA:'🇧🇷', ARG:'🇦🇷', FRA:'🇫🇷', GER:'🇩🇪', ESP:'🇪🇸', POR:'🇵🇹', ITA:'🇮🇹', NED:'🇳🇱',
    URU:'🇺🇾', CRO:'🇭🇷', MEX:'🇲🇽', USA:'🇺🇸', CAN:'🇨🇦', MAR:'🇲🇦', JPN:'🇯🇵', BEL:'🇧🇪',
    SUI:'🇨🇭', SEN:'🇸🇳', KOR:'🇰🇷', AUS:'🇦🇺', DEN:'🇩🇰', TUN:'🇹🇳', KSA:'🇸🇦', ECU:'🇪🇨',
    QAT:'🇶🇦', POL:'🇵🇱', GHA:'🇬🇭', CMR:'🇨🇲', SRB:'🇷🇸', ENG:'🏴', WAL:'🏴', SCO:'🏴', NIR:'🏴',
  };
  return flags[String(tla).toUpperCase()] || '🏳️';
};
