import React, { useCallback, useEffect, useState } from 'react';
import {
  ActivityIndicator,
  FlatList,
  Image,
  Modal,
  RefreshControl,
  SafeAreaView,
  ScrollView,
  StatusBar,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { WebView } from 'react-native-webview';
import styles from './styles';
import {
  NEWS_API_KEY,
  FOOTBALL_DATA_TOKEN,
  FILTROS_NOTICIAS,
  getFlagEmoji,
} from './supabase';

// Escolha qual fase quer mostrar:
// '16_AVOS' = fase de 32 times / Round of 32
// 'OITAVAS' = Round of 16 / oitavas de final
const FASE_MATA_MATA = '16_AVOS';

export default function NoticiasScreen() {
  const [noticias, setNoticias] = useState([]);
  const [jogos, setJogos] = useState([]);
  const [mataMata, setMataMata] = useState([]);
  const [loadingNews, setLoadingNews] = useState(true);
  const [loadingMataMata, setLoadingMataMata] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [filtroAtivo, setFiltroAtivo] = useState(FILTROS_NOTICIAS[0]);
  const [modalVisible, setModalVisible] = useState(false);
  const [noticiaUrl, setNoticiaUrl] = useState('');

  const fetchNoticias = async (query) => {
    setLoadingNews(true);

    try {
      const res = await fetch(
        `https://newsapi.org/v2/everything?q=${encodeURIComponent(
          query
        )}&language=pt&sortBy=publishedAt&pageSize=6&apiKey=${NEWS_API_KEY}`
      );

      const data = await res.json();

      if (data.articles) {
        setNoticias(
          data.articles.filter((art) => art.urlToImage && art.title)
        );
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoadingNews(false);
    }
  };

  const getNomeFase = () => {
    if (FASE_MATA_MATA === 'OITAVAS') return 'Oitavas de Final';
    return '16 avos / Fase de 32';
  };

  const isDataEntre = (dateString, inicio, fim) => {
    if (!dateString) return false;

    const data = new Date(dateString);
    const dataInicio = new Date(inicio);
    const dataFim = new Date(fim);

    return data >= dataInicio && data <= dataFim;
  };

  const isFase16Avos = (match) => {
    const stage = String(match.stage || '').toUpperCase();

    const fasesPossiveis = [
      'LAST_32',
      'ROUND_OF_32',
      'ROUND_32',
      'R32',
      '16_AVOS',
      'SIXTEENTH_FINALS',
    ];

    if (fasesPossiveis.includes(stage)) return true;

    // Fallback por data da Copa 2026:
    // Round of 32 / 16 avos: 28 junho a 3 julho
    return isDataEntre(
      match.utcDate,
      '2026-06-28T00:00:00Z',
      '2026-07-03T23:59:59Z'
    );
  };

  const isFaseOitavas = (match) => {
    const stage = String(match.stage || '').toUpperCase();

    const fasesPossiveis = [
      'LAST_16',
      'ROUND_OF_16',
      'ROUND_16',
      'R16',
      'OITAVAS',
    ];

    if (fasesPossiveis.includes(stage)) return true;

    // Fallback por data da Copa 2026:
    // Oitavas: 4 julho a 7 julho
    return isDataEntre(
      match.utcDate,
      '2026-07-04T00:00:00Z',
      '2026-07-07T23:59:59Z'
    );
  };

  const filtrarMataMataAtual = (matches) => {
    if (!Array.isArray(matches)) return [];

    let filtrados = [];

    if (FASE_MATA_MATA === 'OITAVAS') {
      filtrados = matches.filter(isFaseOitavas);
    } else {
      filtrados = matches.filter(isFase16Avos);
    }

    return filtrados.sort(
      (a, b) => new Date(a.utcDate) - new Date(b.utcDate)
    );
  };

  const fetchDadosFutebol = async () => {
    setLoadingMataMata(true);

    try {
      const resMatches = await fetch(
        'https://api.football-data.org/v4/competitions/WC/matches?status=SCHEDULED,IN_PLAY,PAUSED,FINISHED',
        {
          headers: {
            'X-Auth-Token': FOOTBALL_DATA_TOKEN,
          },
        }
      );

      const dataMatches = await resMatches.json();

      if (dataMatches.matches) {
        const todosJogos = dataMatches.matches;

        // Carrossel pequeno de próximos jogos ou jogos ao vivo
        const proximosOuAoVivo = todosJogos
          .filter(
            (match) =>
              match.status === 'SCHEDULED' ||
              match.status === 'IN_PLAY' ||
              match.status === 'PAUSED'
          )
          .slice(0, 5);

        setJogos(proximosOuAoVivo);

        // Aqui troca a classificação por mata-mata
        const jogosMataMata = filtrarMataMataAtual(todosJogos);
        setMataMata(jogosMataMata);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoadingMataMata(false);
    }
  };

  useEffect(() => {
    fetchNoticias(FILTROS_NOTICIAS[0].query);
    fetchDadosFutebol();
  }, []);

  const onRefresh = useCallback(async () => {
    setRefreshing(true);

    await fetchNoticias(filtroAtivo.query);
    await fetchDadosFutebol();

    setRefreshing(false);
  }, [filtroAtivo]);

  const renderJogoCard = ({ item }) => {
    const hora = new Date(item.utcDate).toLocaleTimeString('pt-BR', {
      hour: '2-digit',
      minute: '2-digit',
    });

    return (
      <View style={styles.jogoCard}>
        <Text style={styles.jogoStatus}>
          {item.status === 'IN_PLAY'
            ? 'AO VIVO'
            : item.status === 'PAUSED'
            ? 'PAUSADO'
            : hora}
        </Text>

        <View style={styles.jogoEquipes}>
          <View style={styles.miniTimeContainer}>
            <Text style={styles.miniBandeira}>
              {getFlagEmoji(item.homeTeam?.tla)}
            </Text>
            <Text style={styles.jogoTeamName}>
              {item.homeTeam?.tla || 'TBD'}
            </Text>
          </View>

          <Text style={styles.jogoScore}>
            {item.score?.fullTime?.home ?? '-'}
          </Text>

          <Text style={styles.jogoVs}>x</Text>

          <Text style={styles.jogoScore}>
            {item.score?.fullTime?.away ?? '-'}
          </Text>

          <View style={styles.miniTimeContainer}>
            <Text style={styles.miniBandeira}>
              {getFlagEmoji(item.awayTeam?.tla)}
            </Text>
            <Text style={styles.jogoTeamName}>
              {item.awayTeam?.tla || 'TBD'}
            </Text>
          </View>
        </View>
      </View>
    );
  };

  const renderMataMataCard = ({ item }) => {
    const data = new Date(item.utcDate).toLocaleDateString('pt-BR', {
      day: '2-digit',
      month: '2-digit',
    });

    const hora = new Date(item.utcDate).toLocaleTimeString('pt-BR', {
      hour: '2-digit',
      minute: '2-digit',
    });

    const statusTexto =
      item.status === 'FINISHED'
        ? 'ENCERRADO'
        : item.status === 'IN_PLAY'
        ? 'AO VIVO'
        : item.status === 'PAUSED'
        ? 'PAUSADO'
        : `${data} • ${hora}`;

    return (
      <View style={[styles.jogoCard, { width: 210, padding: 14 }]}>
        <Text style={styles.jogoStatus}>{statusTexto}</Text>

        <Text
          style={{
            color: '#00FF66',
            fontSize: 11,
            fontWeight: 'bold',
            marginBottom: 8,
            textTransform: 'uppercase',
          }}
        >
          {getNomeFase()}
        </Text>

        <View style={styles.jogoEquipes}>
          <View style={[styles.miniTimeContainer, { width: 52 }]}>
            <Text style={styles.miniBandeira}>
              {getFlagEmoji(item.homeTeam?.tla)}
            </Text>
            <Text style={styles.jogoTeamName} numberOfLines={1}>
              {item.homeTeam?.tla || item.homeTeam?.shortName || 'TBD'}
            </Text>
          </View>

          <Text style={[styles.jogoScore, { fontSize: 18 }]}>
            {item.score?.fullTime?.home ?? item.score?.regularTime?.home ?? '-'}
          </Text>

          <Text style={styles.jogoVs}>x</Text>

          <Text style={[styles.jogoScore, { fontSize: 18 }]}>
            {item.score?.fullTime?.away ?? item.score?.regularTime?.away ?? '-'}
          </Text>

          <View style={[styles.miniTimeContainer, { width: 52 }]}>
            <Text style={styles.miniBandeira}>
              {getFlagEmoji(item.awayTeam?.tla)}
            </Text>
            <Text style={styles.jogoTeamName} numberOfLines={1}>
              {item.awayTeam?.tla || item.awayTeam?.shortName || 'TBD'}
            </Text>
          </View>
        </View>

        {item.score?.winner ? (
          <Text
            style={{
              color: '#888',
              fontSize: 10,
              marginTop: 8,
              textAlign: 'center',
            }}
          >
            Vencedor: {item.score.winner}
          </Text>
        ) : null}
      </View>
    );
  };

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" />

      <View style={styles.header}>
        <Text
          style={styles.headerTitle}
          numberOfLines={1}
          adjustsFontSizeToFit
        >
          🏆 Sport Link
        </Text>
      </View>

      <FlatList
        data={noticias}
        keyExtractor={(item, index) => index.toString()}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            tintColor="#00FF66"
            colors={['#00FF66']}
          />
        }
        renderItem={({ item }) => (
          <TouchableOpacity
            style={styles.newsCard}
            onPress={() => {
              setNoticiaUrl(item.url);
              setModalVisible(true);
            }}
          >
            <Image source={{ uri: item.urlToImage }} style={styles.newsImage} />

            <View style={styles.newsContent}>
              <Text style={styles.newsSource}>
                {item.source?.name || 'Esportes'}
              </Text>

              <Text style={styles.newsTitle}>{item.title}</Text>

              <Text style={styles.newsSummary} numberOfLines={2}>
                {item.description}
              </Text>
            </View>
          </TouchableOpacity>
        )}
        ListHeaderComponent={() => (
          <View>
            <Text style={styles.sectionTitle}>⚽ Próximos Jogos</Text>

            {jogos.length > 0 ? (
              <FlatList
                data={jogos}
                keyExtractor={(item, index) => index.toString()}
                renderItem={renderJogoCard}
                horizontal
                showsHorizontalScrollIndicator={false}
                contentContainerStyle={styles.carouselPadding}
              />
            ) : (
              <Text style={styles.emptyText}>Sem jogos carregados.</Text>
            )}

            <Text style={styles.sectionTitle}>
              🏆 Mata-mata atual — {getNomeFase()}
            </Text>

            {loadingMataMata && !refreshing ? (
              <ActivityIndicator color="#00FF66" />
            ) : mataMata.length > 0 ? (
              <FlatList
                data={mataMata}
                keyExtractor={(item, index) => String(item.id || index)}
                renderItem={renderMataMataCard}
                horizontal
                showsHorizontalScrollIndicator={false}
                contentContainerStyle={styles.carouselPadding}
              />
            ) : (
              <Text style={styles.emptyText}>
                Nenhum jogo encontrado para {getNomeFase()}.
              </Text>
            )}

            <Text style={[styles.sectionTitle, { marginTop: 10 }]}>
              🔥 Últimas Notícias
            </Text>

            <ScrollView
              horizontal
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={styles.filtersContainer}
            >
              {FILTROS_NOTICIAS.map((filtro) => (
                <TouchableOpacity
                  key={filtro.id}
                  style={[
                    styles.filterChip,
                    filtroAtivo.id === filtro.id && styles.filterChipActive,
                  ]}
                  onPress={() => {
                    setFiltroAtivo(filtro);
                    fetchNoticias(filtro.query);
                  }}
                >
                  <Text
                    style={[
                      styles.filterChipText,
                      filtroAtivo.id === filtro.id &&
                        styles.filterChipTextActive,
                    ]}
                  >
                    {filtro.label}
                  </Text>
                </TouchableOpacity>
              ))}
            </ScrollView>

            {loadingNews && !refreshing && (
              <ActivityIndicator
                color="#00FF66"
                style={{ marginTop: 20 }}
              />
            )}
          </View>
        )}
        contentContainerStyle={styles.listPadding}
      />

      <Modal
        visible={modalVisible}
        animationType="slide"
        onRequestClose={() => setModalVisible(false)}
      >
        <SafeAreaView style={styles.modalContainer}>
          <View style={styles.modalHeader}>
            <TouchableOpacity
              style={styles.btnFecharModal}
              onPress={() => setModalVisible(false)}
            >
              <Ionicons name="arrow-back" size={24} color="#00FF66" />
              <Text style={styles.btnFecharModalText}>Voltar</Text>
            </TouchableOpacity>
          </View>

          {noticiaUrl ? (
            <WebView source={{ uri: noticiaUrl }} startInLoadingState />
          ) : null}
        </SafeAreaView>
      </Modal>
    </SafeAreaView>
  );
}